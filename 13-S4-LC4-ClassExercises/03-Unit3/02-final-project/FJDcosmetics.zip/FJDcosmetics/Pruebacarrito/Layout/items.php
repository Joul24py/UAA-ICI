<div class="articulo categoria">
   <div class="categoria">
    <input type="hidden" id="id" value="<?php echo $item['id'];  ?>">
    <div class="imagen"><img src="imagenes/<?php echo $item['imagenes'];?>"/> </div>
    <div class="titulo"><?php echo $item['nombre'];  ?></div>
    <div class="precio">$<?php echo $item['precio'];  ?> MXN</div>
    <div class="botones">
        <button>Agregar al carrito</button>
    </div>
    </div>
</div>

