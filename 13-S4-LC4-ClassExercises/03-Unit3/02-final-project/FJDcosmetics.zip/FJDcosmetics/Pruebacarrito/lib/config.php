<?php

define('HOST', 'localhost');
define('DB', 'tienda');
define('USER', 'root');
define('PASSWORD', '');


?>


